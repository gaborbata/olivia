img2webp -v -lossy -q 70 -d 40 -m 6 0*.webp -o loading.webp
